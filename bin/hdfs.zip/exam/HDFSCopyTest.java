package hdfs.exam;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class HDFSCopyTest {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		FileSystem hdfs = null;
		FSDataInputStream hdfsIn = null;
		FSDataOutputStream hdfsout = null;
		try {
			hdfs = FileSystem.get(conf);

			
			Path path = new Path(args[0]);
			Path inPath = new Path(args[0]);

			hdfsout = hdfs.create(path);
			hdfsIn = hdfs.open(inPath);
		
			int data = hdfsIn.read();
			System.out.println("hdfs에서 읽은 데이터 : "+(char)data);
			hdfsout.writeUTF(args[1]);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

